﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Windows.Forms;


namespace DiarioPessoal
{
    public partial class Form1 : Form
    {
        #region Variaveis

        private string Diario = ""; //irá conter o nome do ficheiro

        public Form1()
        {
            InitializeComponent();
            rbText.TextChanged += richTextBox1_TextChanged;
        }

        #endregion
       
        #region Procedimento Verificar Alterações

        private void VerificarAlteracoes()
        {
            if (rbText.Modified == true)     //O método Modified permite registar se ocorreram alterações ao conteúdo do objeto RichTextBox
            {
                DialogResult resposta = MessageBox.Show("Deseja guardar o texto atual?", "Atenção", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resposta == DialogResult.Yes)
                {
                    if (Diario != "")
                    {
                        rbText.SaveFile(Diario);     //Atualização do ficheiro
                        rbText.Modified = false;
                    }
                    else
                    {
                        GuardarFicheiro();    //Novo ficheiro
                    }
                }
            }
        }
        #endregion

        #region Procedimento Guardar Ficheiro

        private void GuardarFicheiro()
        {
            saveFileDialog1.Filter = "Ficheiro RTF | *.rtf | Ficheiro TXT | *.txt";   //É aberto o ficheiro selecionado.

            saveFileDialog1.FileName = "";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Diario = saveFileDialog1.FileName;    //Gravação do conteúdo em ficheiro.
                rbText.SaveFile(Diario);
                rbText.Modified = false;
            }
        }


        #endregion

        #region Contador de Caracteres
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {            
            int numLetras = rbText.Text.Length;//Contar letras

            string texto = rbText.Text.Trim(); // Contar palavras
            int numPalavras = 0;

            if (!string.IsNullOrEmpty(texto))
            {
                numPalavras = texto.Split(' ').Length;
            }

            // Mostrar os resultados
            label1.Text = "Caracteres: " + numLetras.ToString() + " |Palavras: " + numPalavras.ToString();
        }
        #endregion

        #region Menus

        #region Menu Diario
        private void MeuDiarioNovo_Click(object sender, EventArgs e)
        {
            VerificarAlteracoes();  //Antes de criar um novo documento, verifica se existe alterações e se as pretendemos guardar

            rbText.ResetText();
            rbText.Modified = false;
            Diario = null;
        }

        private void MeuDiarioAbrir_Click(object sender, EventArgs e)
        {
            VerificarAlteracoes();  //Antes de criar um novo documento, verifica se existe alterações e se as pretendemos guardar

            openFileDialog1.Filter = "Ficheiros RTF|  *.rtf | Ficheiros TXT | *.TXT | Todos | *.*";
            openFileDialog1.FileName = "";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Diario = openFileDialog1.FileName; //É aberto o ficheiro selecionado
                rbText.LoadFile(Diario);
                rbText.Modified = false;
            }
        }

        private void MeuDiarioGuardar_Click(object sender, EventArgs e)
        {
            if (Diario != "")
            {
                rbText.SaveFile(Diario);
                rbText.Modified = false;
            }
            else
            {
                GuardarFicheiro();
            }
        }

        private void MeuDiarioSair_Click(object sender, EventArgs e)
        {
            DialogResult resposta = MessageBox.Show("Deseja sair da aplicação?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resposta == DialogResult.Yes)
            {
                VerificarAlteracoes();
                Application.Exit();
            }
        }


        #endregion

        #region Editar

        private void menuEditarCortar_Click(object sender, EventArgs e)
        {
            rbText.Cut(); //O método Cut corta o texto selecionado.
        }

        private void menuEditarCopiar_Click(object sender, EventArgs e)
        {
            rbText.Copy();   //O método Copy copia o texto selecionado para a memória RAM do computador.
        }

        private void menuEditarColar_Click(object sender, EventArgs e)
        {
            rbText.Paste();  //O método Paste permite copiar o texto da memória RAM do computador para a posição do cursor.
        }

        private void menuEditarSelecionarTudo_Click(object sender, EventArgs e)
        {
            rbText.SelectAll();   //O método SelectAll permite selecionar todo o texto do objeto RichTextBox.
        }

        private void menuEditarProcurar_Click(object sender, EventArgs e)
        {
            string txtProcura = Interaction.InputBox("Digite o que procura:", "Procurar", "", 150, 200); //Guardar o texto a procurar usando o InputBox.

            int resultado = rbText.Find(txtProcura);   //O método Find permite procurar no objeto RichTextBox a palavra digitada pelo utilizador

            if (resultado == -1)
                MessageBox.Show("Aviso", "Não foi encontrada a sua procura.", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);  //Se a palavra não for encontrada o método Find devolve - 1.
        }

        #endregion

        #region Formatar

        #region Letras
        private void menuFormatarLetra_Click(object sender, EventArgs e)
        {
            if (rbText.SelectionFont != null)
            {
                fontDialog1.Font = rbText.SelectionFont; //Configuração da caixa de diálogo do tipo de letra com o tipo de letra do texto.
            }
            else
            {
                fontDialog1.Font = null;
            }
            fontDialog1.ShowDialog();
            rbText.SelectionFont = fontDialog1.Font;   //Apresentação da caixa de diálogo do tipo de letra e, após a alteração pelo utilizador, é aplicada ao objeton RichTextBox.
        }

        #endregion

        #region cores
        private void menuFormatarCores_Click(object sender, EventArgs e)
        {

        }
        private void letrasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            rbText.SelectionColor = colorDialog1.Color;
        }
        private void fundoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            rbText.SelectionBackColor = colorDialog1.Color;
        }

        #endregion

        #region Alinhamento     
        private void menuFormatarAlinhamento_Click(object sender, EventArgs e)
        {

        }
        private void esquerdaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rbText.SelectionAlignment = HorizontalAlignment.Left;
        }

        private void centroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rbText.SelectionAlignment = HorizontalAlignment.Center;
        }

        private void direitaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rbText.SelectionAlignment = HorizontalAlignment.Right;
        }
        #endregion

        #endregion

        #region Ajuda
        private void menuAjuda_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
        }
        #endregion

        #endregion
     
    }
}
